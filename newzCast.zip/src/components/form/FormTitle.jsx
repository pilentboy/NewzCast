export default function FormTitle({ title }) {
    return <span className='font-bold text-xs text-purple-1000 text-center'>
        {title}
    </span>
}