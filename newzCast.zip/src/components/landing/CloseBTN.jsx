import { IoMdCloseCircle } from "react-icons/io";

export default function CloseBTN() {
    return (
        <>
            <button className=" absolute top-[-12px] right-[-10px]  text-lg  text-purple-1000 ">
                <IoMdCloseCircle />
            </button>
        </>
    )
}