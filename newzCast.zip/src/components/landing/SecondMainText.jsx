
export default function SecondMainText({ text }) {
    return (
        <>
            <h1 className="text-gray-400 text-sm font-medium leading-4">
                {text}
            </h1>
        </>
    )
}