
function UserID({ id }) {
    return (
        <span className="text-gray-500 font-medium  text-sm mt-2">@{id}</span>)
}

export default UserID