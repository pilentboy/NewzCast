import HomeContainer from "../components/home/HomeContainer"


const Favorites = () => {

    return (
        <HomeContainer>
            <h1>Favorite</h1>
        </HomeContainer>
    )
}

export default Favorites