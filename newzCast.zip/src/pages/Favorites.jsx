

const Favorites = () => {

    return (
        <>
            <h1>Favorites</h1>
        </>
    )
}

export default Favorites