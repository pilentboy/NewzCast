
const Trending = () => {

    return (
        <>
            <h1>Trending</h1>
        </>
    )
}

export default Trending