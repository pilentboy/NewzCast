import HomeNav from "../components/home/HomeNav"

const NewzNav = () => {

    return (
        <>
            <HomeNav />
        </>
    )
}

export default NewzNav