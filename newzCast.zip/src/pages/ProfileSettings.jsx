

const ProfileSettings = () => {

    return (
        <>
            <h1>Profile Settings</h1>
        </>
    )
}

export default ProfileSettings