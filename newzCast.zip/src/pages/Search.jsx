
function Search() {
  return (
    <div>Search</div>
  )
}

export default Search