import HomeContainer from "../components/home/HomeContainer"


function Settings() {

  return (

    <HomeContainer>
      <h1>settings</h1>
    </HomeContainer>

  )



}

export default Settings