
const VerifyClient = () => {

    return (
        <>
            <h1>Verify Client</h1>
        </>
    )
}

export default VerifyClient